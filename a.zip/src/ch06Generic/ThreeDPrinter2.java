package ch06Generic;

public class ThreeDPrinter2 {

	private Plastic material;
	
	public Plastic getMaterial() {
		return material;
	}

	public void setMaterial(Plastic material) {
		this.material = material;
	}

	
}
