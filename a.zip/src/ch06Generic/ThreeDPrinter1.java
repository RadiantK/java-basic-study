package ch06Generic;

public class ThreeDPrinter1 {

	private Powder material;
		
	public Powder getMaterial() {
		return material;
	}

	public void setMaterial(Powder material) {
		this.material = material;
	}


}