package ch07T_extends;

public abstract class Material {

	public abstract void doPrinting();
}
