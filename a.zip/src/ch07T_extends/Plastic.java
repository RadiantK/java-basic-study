package ch07T_extends;

public class Plastic extends Material {

	public String toString() {
		return "���� Plastic �Դϴ�.";
	}

	@Override
	public void doPrinting() {
		
	}
}