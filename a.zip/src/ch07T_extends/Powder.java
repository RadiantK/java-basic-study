package ch07T_extends;

public class Powder extends Material {

	public String toString() {
		return "���� Powder �Դϴ�.";
	}

	@Override
	public void doPrinting() {
		
	}
}